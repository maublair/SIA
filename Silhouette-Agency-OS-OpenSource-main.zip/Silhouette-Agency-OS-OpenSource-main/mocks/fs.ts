export const writeFileSync = () => { };
export const readFileSync = () => '';
export const existsSync = () => false;
export const promises = {};

export default {
    writeFileSync,
    readFileSync,
    existsSync,
    promises
};
