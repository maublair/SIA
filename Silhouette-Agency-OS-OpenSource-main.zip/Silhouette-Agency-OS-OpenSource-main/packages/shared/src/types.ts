// Shared types for Silhouette Agency OS
// This file exports types used by both client and server

// Re-export everything from the main types file
// In a future migration, these types will be defined here directly

export { };

// Placeholder - types will be migrated here gradually
// For now, the original types.ts in root remains the source of truth
